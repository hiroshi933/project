package com.example.mad22

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer

class LaunchActiivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launch_actiivity)
        val timer = object:CountDownTimer(millislnFuture: 3000, countDownlnterval: 1000){
            override fun onTick(millisUntilFuture: Long){

            }
        }
    }
}