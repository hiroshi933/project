﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommunicationTechnology.Models
{
    public class Core
    {
        public CommunicationBDEntities context = new CommunicationBDEntities();
    }
}
